/**
 * Ez a csomag a Wumpus World játékhoz
 * tartozó osztályokat és fájlokat
 * tartalmazza.
 * A csomag felelős a játék logikájának
 * és implementációjának kezeléséért.
 */
package wumpusworld;
